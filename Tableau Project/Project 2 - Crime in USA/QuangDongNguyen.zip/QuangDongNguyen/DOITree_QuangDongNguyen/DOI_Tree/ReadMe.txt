To run the program, 
+ First you need install Java RunTime Environment. The software can be downloaded at: http://www.oracle.com/technetwork/java/javase/downloads/jre8-downloads-2133155.html

+ Click on the TreeVis.jar to exercute the program.