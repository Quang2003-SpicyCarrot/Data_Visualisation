To run Treemap, simply give the command "run"
(which will execute the batch file run.bat).

or click on treemap.jar file
